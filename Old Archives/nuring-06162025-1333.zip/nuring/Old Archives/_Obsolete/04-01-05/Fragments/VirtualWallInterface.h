#pragma once

class VirtualWallInterface { };