/* Amplifier Control Class */

// Ensure this header is only initialized once
#pragma once

class AmplifierClass {

private:


public:
  // Constructor
  AmplifierClass() {
    // Calls
  }
};