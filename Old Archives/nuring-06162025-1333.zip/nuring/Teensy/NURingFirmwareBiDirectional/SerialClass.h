#pragma once

class SerialClass{ 



};
