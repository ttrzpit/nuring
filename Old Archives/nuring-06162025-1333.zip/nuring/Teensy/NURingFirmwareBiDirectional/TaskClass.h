#pragma once


class TaskClass{



} ;