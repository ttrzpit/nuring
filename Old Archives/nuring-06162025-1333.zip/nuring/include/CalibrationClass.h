#pragma once

// Memory for shared data
#include <memory>

// OpenCV core functions
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>	  // For pollKey()

// Runtime configuration
#include "config.h"

// For vector summing
#include <numeric>


// Forward declarations
class SystemDataManager;
struct ManagedData;


/** 
 * @brief Calibration class definition
 */
class CalibrationClass {

public:
	// Constructor
	CalibrationClass( SystemDataManager& dataHandle );

	// Public class functions
	void Initialize();
	void Update();
	void End();
	void Close();

private:
	// Data manager handle
	SystemDataManager&			 dataHandle;
	std::shared_ptr<ManagedData> shared;

	// Private class functions

	void FinishCalibration();



	// Private variables
	std::vector<cv::Point3i> calibrationPoints;
	std::vector<int>		 calibrationZPoints;

	// Calibration window name
	std::string winCalibration = "Calibration Window";

	// ArUco tag
	cv::Mat matAruco = cv::imread( "/home/tom/Code/nuring/images/tags/aruco-08-20mm-scaled.png" );

	// Placeholder for average
	cv::Point3f runningAverage = cv::Point3f( 0.0f, 0.0f, 0.0f );
	bool		outputCreated  = false;

	// Calibration screen
	cv::Mat matCalibration = cv::Mat( CONFIG_TOUCHSCREEN_HEIGHT_PX, CONFIG_TOUCHSCREEN_WIDTH_PX, CV_8UC3 );
};
