
#include "TasksClass.h"



TasksClass::TasksClass( SystemDataManager& ctx, TimingClass& timerHandle, LoggingClass& loggerHandle )
	: dataHandle( ctx )
	, shared( ctx.getData() )
	, Timer( timerHandle )
	, Logger( loggerHandle ) {
	// Stuff
}

/* 
 * 
 * 
 *  
 * 
 * 
 * 
 * 
 * 
 * 
 *  =========================================================================================
 *  ========================================================================================= 
 * 
 *   CCCCCCC    AAAA    LL       IIIIII  BBBBBBB   RRRRRR     AAAA   TTTTTTTT  EEEEEEE
 *  CC         AA  AA   LL         II    BB   BBB  RR   RR   AA  AA     TT     EE
 *  CC         AA  AA   LL         II    BB   BBB  RR   RR   AA  AA     TT     EE
 *  CC        AAAAAAAA  LL         II    BBBBBBB   RRRRRR   AAAAAAAA    TT     EEEEE
 *  CC        AA    AA  LL         II    BB   BBB  RR  RR   AA    AA    TT     EE
 *  CC        AA    AA  LL         II    BB   BBB  RR   RR  AA    AA    TT     EE
 *   CCCCCCC  AA    AA  LLLLLLL  IIIIII  BBBBBBB   RR   RR  AA    AA    TT     EEEEEEE
 * 
 *  ========================================================================================= 
 *  ========================================================================================= 
 */



void TasksClass::Calibration() {

	// If the task isn't running yet, start it first
	if ( !shared->Task.isRunning ) {

		// Start calibration
		CalibrationStart();

	} else {

		// Calibration complete, wait for touch to close
		if ( isFinishing ) {

			if ( shared->Touchscreen.isTouched ) {

				// Set marker
				shared->Telemetry.activeID = 1;

				// isComplete			   = true;
				isFinishing			   = false;
				shared->Task.isRunning = false;
				shared->Task.state	   = taskEnum::IDLE;

				std::cout << "TASK COMPLETE!";
				cv::imshow( winTaskBackground, 0 );
			}

		} else {

			// Update
			CalibrationUpdate();
		}
	}
}

void TasksClass::CalibrationStart() {

	// Set marker
	shared->Telemetry.activeID = 8;

	// Start calibration
	shared->Task.isRunning = true;
	isFinishing			   = false;
	std::cout << "Starting calibration!\n";

	// Clear calibration values
	shared->Calibration.calibratedOffetMM = cv::Point3i( 0, 0, 0 );

	// Initialize interface
	InitializeInterface();

	// Copy tag
	matAruco08.copyTo( matTaskBackground( cv::Rect( posX, posY, matAruco08.cols, matAruco08.rows ) ) );

	// Add instructional text
	std::string line0 = "Please touch the screen while keeping the center of the camera aligned with the dot below. ";
	cv::putText( matTaskBackground, line0, cv::Point( 10, 40 ), cv::FONT_HERSHEY_SIMPLEX, 1.2, CONFIG_colBlack, 2 );

	// Show screen
	cv::imshow( winTaskBackground, matTaskBackground );
}



void TasksClass::CalibrationUpdate() {

	// Check if touch detected
	if ( shared->Touchscreen.isTouched ) {

		// Update screen offset with position
		shared->Calibration.calibratedOffetPX = cv::Point3i( shared->Touchscreen.positionTouched );

		// Update flags
		shared->Calibration.isCalibrated = true;
		shared->Touchscreen.isTouched	 = false;

		// End calibration
		CalibrationFinish();
	}
}


void TasksClass::CalibrationFinish() {

	// Calculate screen touchpoint
	cv::Point2i touchPointPX = cv::Point2i( shared->Calibration.calibratedOffetPX.x, shared->Calibration.calibratedOffetPX.y );

	// Draw elements
	cv::line( matTaskBackground, CONFIG_TOUCHSCREEN_CENTER, cv::Point2i( CONFIG_TOUCHSCREEN_CENTER.x, touchPointPX.y ), CONFIG_colMagMd, 2 );						 // X
	cv::line( matTaskBackground, cv::Point2i( CONFIG_TOUCHSCREEN_CENTER.x, touchPointPX.y ), cv::Point2i( touchPointPX.x, touchPointPX.y ), CONFIG_colMagMd, 2 );	 // Y
	cv::line( matTaskBackground, CONFIG_TOUCHSCREEN_CENTER, touchPointPX, CONFIG_colMagMd, 2 );																		 // Mag
	cv::circle( matTaskBackground, touchPointPX, 20, CONFIG_colMagMd, -1 );

	// Store offset values
	shared->Calibration.calibratedOffetMM.x = ( CONFIG_TOUCHSCREEN_CENTER.x - touchPointPX.x ) * PX2MM;
	shared->Calibration.calibratedOffetMM.y = ( CONFIG_TOUCHSCREEN_CENTER.y - touchPointPX.y ) * PX2MM;
	shared->Calibration.calibratedOffetMM.z = shared->Telemetry.positionFilteredNewMM.z;

	// Update status string
	shared->Display.statusString = "TasksClass: Calibration complete!";

	// Update flags
	isFinishing = true;

	// Show screen
	cv::imshow( winTaskBackground, matTaskBackground );
}



/* 
 * 
 * 
 *  
 * 
 * 
 * 
 * 
 * 
 * 
 *  =========================================================================================
 *  ========================================================================================= 
 * 
 *   FFFFFFF  IIIIII  TTTTTTT  TTTTTTT   SSSSS
 *   FF         II      TT        TT    SS
 *   FF         II      TT        TT    SS
 *   FFFFF      II      TT        TT     SSSSS
 *   FF         II      TT        TT         SS
 *   FF         II      TT        TT         SS
 *   FF       IIIIII    TT        TT     SSSSS
 * 
 *  ========================================================================================= 
 *  ========================================================================================= 
 */


void TasksClass::Fitts() {

	// Initialize if task is not running
	if ( !shared->Task.isRunning ) {

		// Start fitts task
		FittsStart();

	}
	// If task is already running, check if finishing or just updating
	else {

		// Check if task finishing
		if ( isFinishing ) {

			isFinishing					 = false;
			shared->Task.isRunning		 = false;
			shared->Task.state			 = taskEnum::IDLE;
			shared->Display.statusString = "Fitts task complete!";

			// Finish task
			FittsFinish();

		}
		// Otherwise, just update
		else {

			// Update
			FittsUpdate();
		}
	}


	// 	// Set active marker
	// 	shared->Telemetry.activeID = 1;

	// 	// Start timer for measuring loop frequency
	// 	Timing.TaskTimerStart();



	// 	// Update flags
	// 	shared->Logging.isLoggingActivelyRunning = true;
	// 	shared->Task.isRunning		Start			 = true;

	// }
	// // Update since task is running
	// else {

	// 	// Update logging entries
	// 	shared->loggingVariable1 = std::to_string( shared->Touchscreen.isTouched );
	// 	shared->loggingVariable2 = shared->Serial.packetOut.substr( 0, shared->Serial.packetOut.length() - 1 );
	// 	shared->loggingVariable3 = shared->Serial.packetIn.substr( 0, shared->Serial.packetIn.length() - 1 );
	// 	shared->loggingVariable4 = std::to_string( shared->Serial.isSerialSending ) + "," + std::to_string( shared->Serial.isSerialSendOpen ) + "," + std::to_string( shared->Serial.isSerialReceiving ) + "," + std::to_string( shared->Serial.isSerialReceiveOpen );
	// 	shared->loggingVariable5 = shared->FormatDecimal( shared->controllerKp.x, 1, 1 ) + "," + shared->FormatDecimal( shared->controllerKp.y, 1, 1 ) + "," + shared->FormatDecimal( shared->controllerKi.x, 1, 1 ) + "," + shared->FormatDecimal( shared->controllerKi.y, 1, 1 ) + ","
	// 		+ shared->FormatDecimal( shared->controllerKd.x, 1, 1 ) + "," + shared->FormatDecimal( shared->controllerKd.y, 1, 1 );
	// 	Logging.AddEntry();
	// }
}

void TasksClass::FittsStart() {

	// Initialize interface
	InitializeInterface();

	// Initialize runtime variables
	shared->Task.isRunning		 = true;
	isFinishing					 = false;
	shared->Display.statusString = "Starting Fitts task...";

	

	// Generate random seed
	std::srand( time( NULL ) );

	// Add instructional text
	std::string line0 = "Fitts task running...";
	cv::putText( matTaskBackground, line0, cv::Point( 10, 40 ), cv::FONT_HERSHEY_SIMPLEX, 1.2, CONFIG_colBlack, 2 );

	// Calculate marker position based on selection
	shared->Telemetry.isTargetFound = false;
	FittsGeneratePosition();

	// Show screen
	cv::imshow( winTaskBackground, matTaskBackground );

	// Start task timer
	Timer.TaskTimerStart();

	// Initialize logging variables
	FittsLoggingStart();

}

void TasksClass::FittsUpdate() { }

void TasksClass::FittsFinish() { }

void TasksClass::FittsGeneratePosition() {

	// Select generation type
	switch ( shared->Task.command ) {

		// Generate random marker position on X axis
		case 'x': {

			// Calculate marker boundaries
			minX = CONFIG_TOUCHSCREEN_EXCLUSION_ZONE;
			maxX = CONFIG_TOUCHSCREEN_WIDTH_PX - CONFIG_TOUCHSCREEN_EXCLUSION_ZONE - 72;

			// Calculate marker position
			shared->Task.targetPosition.x = minX + ( rand() % ( maxX - minX + 1 ) ) + ( matAruco01.rows / 2 );
			shared->Task.targetPosition.y = ( CONFIG_TOUCHSCREEN_HEIGHT_PX / 2 ) + ( matAruco01.rows / 2 );

			// Return
			shared->Display.statusString = "TasksClass: Generating random X position...";
			break;
		}

		// Generate random marker position on Y axis
		case 'y': {

			// Calculate marker boundaries
			minY = 0 + 72;
			maxY = CONFIG_TOUCHSCREEN_HEIGHT_PX - CONFIG_TOUCHSCREEN_EXCLUSION_ZONE - 93;

			// Calculate marker position
			shared->Task.targetPosition.x = ( CONFIG_TOUCHSCREEN_WIDTH_PX / 2 ) + ( matAruco01.rows / 2 );
			shared->Task.targetPosition.y = minY + ( rand() % ( maxY - minY + 1 ) ) + ( matAruco01.rows / 2 );

			// Return
			shared->Display.statusString = "TasksClass: Generating random Y position...";
			break;
		}

		// Generate random marker position on XY plane
		case 'z': {

			// Calculate marker boundaries
			minX = 0 + CONFIG_TOUCHSCREEN_EXCLUSION_ZONE;
			maxX = CONFIG_TOUCHSCREEN_WIDTH_PX - CONFIG_TOUCHSCREEN_EXCLUSION_ZONE - 72;
			minY = 0 + 72;
			maxY = CONFIG_TOUCHSCREEN_HEIGHT_PX - CONFIG_TOUCHSCREEN_EXCLUSION_ZONE - 93;

			// Calculate marker position
			shared->Task.targetPosition.x = minX + ( rand() % ( maxX - minX + 1 ) ) - matAruco01.cols / 2;
			shared->Task.targetPosition.y = minY + ( rand() % ( maxY - minY + 1 ) ) - ( matAruco01.rows / 2 );

			// Return
			shared->Display.statusString = "TasksClass: Generating random XY position...";
			break;
		}

		// Generate marker moving at constant velocity
		case 'v': {

			shared->Display.statusString = "TasksClass: Generating constant velocity marker...";
			break;
		}

		// Default case for error
		default: {

			shared->Display.statusString = "TasksClass: Incorrect Fitts axis request!";
			break;
		}
	}
}


/**
 * @brief Initialize and start logging
 * 
 */
void TasksClass::FittsLoggingStart() {

	// Customize header
	shared->Logging.header1 = "TouchDetected";
	shared->Logging.header2 = "OutgoingPacket";
	shared->Logging.header3 = "IncomingPacket";
	shared->Logging.header4 = "GainPropAb, GainPropAd, GainPropFl, GainPropEx, PropA, PropB, PropC";
	shared->Logging.header5 = "GainIntegAb, GainIntegAd, GainIntegFl, GainIntegEx, IntegA, IntegB, IntegC";
	shared->Logging.header6 = "GainDerivAb, GainDerivAd, GainDerivFl, GainDerivEx, DerivA, DerivB, DerivC";

	// Initialize and add initial entry
	Logger.Initialize();
}





/* 
 *
 * 
 *
 *  
 * 
 * 
 *  =========================================================================================
 *  ========================================================================================= 
 * 
 *   GGGGGGG  EEEEEEE  NNN   NN  EEEEEEE  RRRRRR     AAA    LL
 *  GG        EE       NNNN  NN  EE       RR   RR   AA AA   LL
 *  GG        EE       NN NN NN  EE       RR   RR   AA AA   LL
 *  GG  GGG   EEEEE    NN  NNNN  EEEEE    RRRRRR   AAAAAAA  LL
 *  GG   GG   EE       NN   NNN  EE       RR  RR   AA   AA  LL
 *  GG   GG   EE       NN   NNN  EE       RR   RR  AA   AA  LL
 *   GGGGGGG  EEEEEEE  NN   NNN  EEEEEEE  RR   RR  AA   AA  LLLLLLL
 * 
 *  ========================================================================================= 
 *  ========================================================================================= 
 */



void TasksClass::InitializeInterface() {

	// Configure interface
	cv::namedWindow( winTaskBackground, cv::WINDOW_FULLSCREEN );
	cv::setWindowProperty( winTaskBackground, cv::WindowPropertyFlags::WND_PROP_TOPMOST, 1.0 );
	cv::moveWindow( winTaskBackground, 3440, 0 );
	cv::setWindowProperty( winTaskBackground, cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN );


	// Copy marker to mat
	matTaskBackground = CONFIG_colWhite;
}