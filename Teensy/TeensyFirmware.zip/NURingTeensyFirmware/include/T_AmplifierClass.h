/** Amplifier Class **/

#pragma once

// Memory for shared data
#include "T_Config.h"
#include <Arduino.h>
#include <memory>

// Forward declarations
class SharedDataManager;
struct ManagedData;

// Hardware serial ports
#define SerialA Serial5	   // AdEx serial
#define SerialB Serial4	   // AbEx serial
#define SerialC Serial3	   // Flex serial

/** 
 * @brief Amplifier  class definition
 */
class T_AmplifierClass {

public:
	// Default constructor
	T_AmplifierClass( SharedDataManager& dataHandle );

	// Public functions
	void Begin();
	void Disable();
	void DrivePWM();
	void Enable();
	void ReadMotorEncoders();
	void ZeroAmplifierOutput();
	void ResetMotorEncoders();
	void Update();


private:
	// Data manager handle
	SharedDataManager&			 dataHandle;
	std::shared_ptr<ManagedData> shared;

	// Private functions
	void ResetIntoPwmMode();
	void Reset();
    void ParseEncoderPacketA() ;
    void ParseEncoderPacketB() ;
    void ParseEncoderPacketC() ;

	// Serial commands
	String asciiSetCurrentMode	= "s r0x24 3\n";
	String asciiSetEncoderCountZero = "s r0x17 0\n";
	String asciiGetEncoderCount = "g r0x17\n";
};