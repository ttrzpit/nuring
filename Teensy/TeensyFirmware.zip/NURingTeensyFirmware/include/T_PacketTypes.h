/** Packet Types **/

#pragma once

// Memory for shared data
#include "T_Config.h"
#include <Arduino.h>


// Pragmas to packet data without spaces
#pragma pack( push, 1 )

// Packet for incoming data
struct Packet_DrivePWM {

	uint8_t	 counter;	   // Revolving counter 0 to 255
	uint8_t	 isEnabled;	   // Should the motors be enabled?
	uint16_t pwmA;		   // PWM for A
	uint16_t pwmB;		   // PWM for B
	uint16_t pwmC;		   // PWM for C
};

// Packet for encoder values
struct Packet_MeasureLimits {

	// Encoder values
	uint8_t	 isEnabled;	   // Should the motors be enabled?
	int16_t encA;		 // PWM for A
	int16_t encB;		 // PWM for B
	int16_t encC;		 // PWM for C
};

#pragma pack( pop )

// Header char type char amplifierState uint8_t outA uint8_t outB uint8_t outC uint8_t currentA uint8_t currentB uint8_t currentC uint8_t encA int16_t encB int16_t encC int16_t footer char
// hwSerialMessageTypeA = "SET_BAUD" ;
// SerialA.print ( "s r0x90 115237\n" ) ;
// SerialA.end() ;
// SerialA.begin ( 115237 ) ;
// delay ( 100 ) ;

// // Read baud rate to verify change
// hwSerialMessageTypeA = "GET_BAUD" ;
// SerialA.print ( "g r0x90\n" ) ;
// delay ( 100 ) ;

// // Reset encoder count
// hwSerialMessageTypeA = "SET_COUNT" ;
// SerialA.print ( "s r0x17 0\n" ) ;
// delay ( 100 ) ;

// // Read amp name
// hwSerialMessageTypeA = "GET_NAME" ;
// SerialA.print ( "g f0x92\n" ) ;
// delay ( 100 ) ;