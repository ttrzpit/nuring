/** SharedDataManager Class Header */

#pragma once

#pragma once

// Memory for shared data
#include "T_Config.h"
#include <Arduino.h>
#include <memory>



// Shared data manager
class SharedDataManager;
struct ManagedData;


struct AmplifierStruct {

	// Amplifier enabled flags
	bool isEnabled		  = false;
	bool isEncoderReset	  = false;

	// Amplifer variables
	uint16_t commandedPwmA = AMPLIFIER_PWM_ZERO;
	uint16_t commandedPwmB = AMPLIFIER_PWM_ZERO;
	uint16_t commandedPwmC = AMPLIFIER_PWM_ZERO;
	uint32_t encoderCountA = 0;
	uint32_t encoderCountB = 0;
	uint32_t encoderCountC = 0;

	bool isEncoderWaitingA = false ;
	bool isEncoderWaitingB = false ;
	bool isEncoderWaitingC = false ;

};

struct LEDStruct {

	// Flags
	bool isOnA = false;
	bool isOnB = false;
	bool isOnC = false;
};


/**
 * @brief Struct for serial port data
 * 
 */
struct SerialStruct {

	// Serial flags
	bool isIncomingPacketReady = false;
	bool isOutgoingPacketReady = false;

	// Packets
	String packetIn	 = "";
	String packetOut = "";
};



/**
 * @brief Struct for system data and flags
 * 
 */
struct SystemStruct {

	String state = "WAITING";
};



struct TimingStruct {

	// Interval timer periods
	uint16_t periodAmplifier = 1000000 / TIMING_FREQ_AMPLIFIER_DRIVE;
	uint16_t periodSerial	 = 1000000 / TIMING_FREQ_AMPLIFIER_SERIAL;
};



/**
 * @brief Main struct that gets shared
 * 
 */
struct ManagedData {

	// Declare system structs
	AmplifierStruct Amplifier;
	LEDStruct		LED;
	SerialStruct	Serial;
	SystemStruct	System;
	TimingStruct	Timing;
};


/**
 * @brief 
 * 
 */
class SharedDataManager {
public:
	// Class
	SharedDataManager();

	// Functions
	std::shared_ptr<ManagedData> getData();


private:
	std::shared_ptr<ManagedData> data;
};