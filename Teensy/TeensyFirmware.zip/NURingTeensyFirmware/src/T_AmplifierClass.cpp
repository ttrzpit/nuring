// Call to class header
#include "T_AmplifierClass.h"

// System data manager
#include "T_SharedDataManagerClass.h"

T_AmplifierClass::T_AmplifierClass( SharedDataManager& ctx )
	: dataHandle( ctx )
	, shared( ctx.getData() ) {};


/**
 * @brief Initialize the incoming and outgoing serial ports
 * 
 */
void T_AmplifierClass::Begin() {

	// Configure pin directions
	pinMode( AMPLIFIER_PIN_ENABLE_A, OUTPUT );
	pinMode( AMPLIFIER_PIN_ENABLE_B, OUTPUT );
	pinMode( AMPLIFIER_PIN_ENABLE_C, OUTPUT );
	pinMode( AMPLIFIER_PIN_PWM_A, OUTPUT );
	pinMode( AMPLIFIER_PIN_PWM_B, OUTPUT );
	pinMode( AMPLIFIER_PIN_PWM_C, OUTPUT );

	// Disable amplfiers
	Disable();

	// Set analog resolution
	analogWriteResolution( 12 );

	// Set initial state at zero
	ZeroAmplifierOutput();

	// Establish hardware serial connection to amplifiers
	SerialA.begin( 9600 );
	SerialB.begin( 9600 );
	SerialC.begin( 9600 );
	delay( 1000 );

	// Reset amplifiers into PWM mode (for cogging compensation)
	ResetIntoPwmMode();

	// Enable amplifiers
	Enable();
}



/**
 * @brief Disable amplifiers
 * 
 */
void T_AmplifierClass::Disable() {

	// Send enable commands
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_A, LOW );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_B, LOW );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_C, LOW );

	// Update enable flags
	shared->Amplifier.isEnabled = false;
}



/**
 * @brief Sends PWM signals to amplifier
 * 
 */
void T_AmplifierClass::DrivePWM() {

	// Constrain values as a precaution
	shared->Amplifier.commandedPwmA = constrain( shared->Amplifier.commandedPwmA, AMPLIFIER_PWM_MAX, AMPLIFIER_PWM_ZERO );
	shared->Amplifier.commandedPwmB = constrain( shared->Amplifier.commandedPwmB, AMPLIFIER_PWM_MAX, AMPLIFIER_PWM_ZERO );
	shared->Amplifier.commandedPwmC = constrain( shared->Amplifier.commandedPwmC, AMPLIFIER_PWM_MAX, AMPLIFIER_PWM_ZERO );

	// Send command to amplifiers
	analogWrite( AMPLIFIER_PIN_PWM_A, shared->Amplifier.commandedPwmA );
	analogWrite( AMPLIFIER_PIN_PWM_B, shared->Amplifier.commandedPwmB );
	analogWrite( AMPLIFIER_PIN_PWM_C, shared->Amplifier.commandedPwmC );
}



/**
 * @brief Enable amplifiers
 * 
 */
void T_AmplifierClass::Enable() {

	// Send enable commands
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_A, HIGH );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_B, HIGH );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_C, HIGH );

	// Update enable flags
	shared->Amplifier.isEnabled = true;
}



/**
 * @brief Reset amplifiers 
 * 
 */
void T_AmplifierClass::Reset() {

	// Send reset commands to amp A (high->low->high)
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_A, HIGH );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_A, LOW );
	delay( 500 );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_A, HIGH );

	// Send reset commands to amp B (high->low->high)
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_B, HIGH );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_B, LOW );
	delay( 500 );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_B, HIGH );

	// Send reset commands to amp C (high->low->high)
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_C, HIGH );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_C, LOW );
	delay( 500 );
	digitalWriteFast( AMPLIFIER_PIN_ENABLE_C, HIGH );
}



/**
 * @brief Reset the amplifiers into PWM Current mode
 *        ( needed for cogging compensation )
 * 
 */
void T_AmplifierClass::ResetIntoPwmMode() {

	// Sent reset commands
	Reset();

	// Sent serial command to use PWM current mode
	SerialA.print( asciiSetCurrentMode );
	delay( 500 );
	SerialB.print( asciiSetCurrentMode );
	delay( 500 );
	SerialC.print( asciiSetCurrentMode );
	delay( 500 );
}



/**
 * @brief Main update functions, handles amplifier operations
 * 
 */
void T_AmplifierClass::Update() {

	// Respond according to state
	if ( shared->System.state == "RUNNING" ) {

		// Send drive command if amplifier is enabled
		if ( shared->Amplifier.isEnabled ) {
			DrivePWM();
		}

	} else if ( shared->System.state == "MEASURE_LIMITS" ) {

		// Check if encoders have been zeroed
		if ( !shared->Amplifier.isEncoderReset ) {

			// Zero encoders
			ResetMotorEncoders();
		}

		// Read encoder data
		ReadMotorEncoders();
	}
}


/**
 * @brief Set amplifier values to zero (no current)
 * 
 */
void T_AmplifierClass::ZeroAmplifierOutput() {
	shared->Amplifier.commandedPwmA = AMPLIFIER_PWM_ZERO;
	shared->Amplifier.commandedPwmB = AMPLIFIER_PWM_ZERO;
	shared->Amplifier.commandedPwmC = AMPLIFIER_PWM_ZERO;
}



/**
 * @brief Zero motor encoder values
 * 
 */
void T_AmplifierClass::ResetMotorEncoders() {

	// Disable motors for safety
	shared->Amplifier.isEnabled = false;

	// Send encoder reset command and update flag that data is ready
	SerialA.print( asciiSetEncoderCountZero );
	shared->Amplifier.isEncoderWaitingA = true;
	SerialB.print( asciiSetEncoderCountZero );
	shared->Amplifier.isEncoderWaitingB = true;
	SerialC.print( asciiSetEncoderCountZero );
	shared->Amplifier.isEncoderWaitingC = true;

	// Update reset flag
	shared->Amplifier.isEncoderReset = true;
}



/**
 * @brief Read motor encoders
 * 
 */
void T_AmplifierClass::ReadMotorEncoders() {

	// Read encoderA
	SerialA.print( asciiGetEncoderCount );
	shared->Amplifier.isEncoderWaitingA = true;
	ParseEncoderPacketA();

	// // Read encoderB
	// SerialB.print( asciiGetEncoderCount );
	// shared->Amplifier.isEncoderWaitingB = true;
	// void ParseEncoderPacketB();

	// // Read encoderC
	// SerialC.print( asciiGetEncoderCount );
	// shared->Amplifier.isEncoderWaitingC = true;
	void ParseEncoderPacketC();
}


void T_AmplifierClass::ParseEncoderPacketA() {

	// Variables for reading
	static char	   encoderBuffer[32];
	static uint8_t idx = 0;

	// Check if data waiting via serial
	if ( shared->Amplifier.isEncoderWaitingA ) {

		// Cycle over data
		while ( SerialA.available() ) {

			// Read character
			char c = SerialA.read();

			// Parse string when terminating character appears
			if ( c == '\n' ) {
				encoderBuffer[idx] = '\0' ;

				// Verify valid packet
				if ( encoderBuffer[0] == 'v' && encoderBuffer[1] == ' ' ) {

					// Store value
					shared->Amplifier.encoderCountA = atoi( &encoderBuffer[2]) ;

					// Update flag
					shared->Amplifier.isEncoderWaitingA = false; 
				}

				// Reset index
				idx = 0 ;

			} else if ( idx < sizeof ( encoderBuffer) - 1 ) { 
				
				// Store character while within buffer size
				encoderBuffer[idx++] = c ;

			} else { 

				// Reset in case of buffer overflow
				idx = 0 ; 

			}
		}
	}
}
