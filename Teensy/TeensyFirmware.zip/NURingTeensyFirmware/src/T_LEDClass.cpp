// Call to class header
#include "T_LEDClass.h"



T_LEDClass::T_LEDClass( SharedDataManager& ctx )
	: dataHandle( ctx )
	, shared( ctx.getData() ) {};


/**
 * @brief Initialize the incoming and outgoing serial ports
 * 
 */
void T_LEDClass::Begin() {

	// Configure pin directions
	pinMode( LED_PIN_A, OUTPUT );
	pinMode( LED_PIN_B, OUTPUT );
	pinMode( LED_PIN_C, OUTPUT );

	// Set initial states
	digitalWriteFast( LED_PIN_A, LOW );
	digitalWriteFast( LED_PIN_B, LOW );
	digitalWriteFast( LED_PIN_C, LOW );
}



/**
 * @brief Main callback function for updating LEDs
 * 
 */
void T_LEDClass::Update() {

    // Set LED states
    digitalWriteFast ( LED_PIN_A , shared->LED.isOnA ) ;
    digitalWriteFast ( LED_PIN_B , shared->LED.isOnB ) ;
    digitalWriteFast ( LED_PIN_C , shared->LED.isOnC ) ;
 }