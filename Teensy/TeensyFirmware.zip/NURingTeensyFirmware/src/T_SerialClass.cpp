// Call to class header
#include "T_SerialClass.h"

// System data manager
#include "T_SharedDataManagerClass.h"

// Set initial values
uint8_t T_SerialClass::buffer[64];
uint8_t T_SerialClass::idx			  = 0;
uint8_t T_SerialClass::state		  = 0;
uint8_t T_SerialClass::expectedLength = 0;

T_SerialClass::T_SerialClass( SharedDataManager& ctx )
	: dataHandle( ctx )
	, shared( ctx.getData() ) {};


/**
 * @brief Initialize the incoming and outgoing serial ports
 * 
 */
void T_SerialClass::Begin() {

	SerialIn.begin( 1000000 );	  // Input
	SerialOut.begin( 1000000 );
}



/**
 * @brief Initialize the incoming and outgoing serial ports
 * 
 */
void T_SerialClass::Update() {

	// Reset values
	idx			   = 0;
	state		   = 0;
	expectedLength = 0;

	// Loop over bytes
	while ( SerialIn.available() ) {

		uint8_t byte = SerialIn.read();

		if ( state == 0 && byte == 0xAA ) {	   // Check if start byte detected

			// Reset index
			idx = 0;

			// Save byte and update state
			buffer[idx++] = byte;
			state		  = 1;

		} else if ( state == 1 ) {	  // Get type

			// Save byte and update
			buffer[idx++] = byte;
			state		  = 2;
		} else if ( state == 2 ) {	  // Checksum

			// Save expected length
			expectedLength = byte;

			// Save byte and update
			buffer[idx++] = byte;
			state		  = 3;

		} else if ( state == 3 ) {	  // Read rest of packet

			// Save byte
			buffer[idx++] = byte;

			// Check for end of packet
			if ( idx == 3 + expectedLength + 1 ) {

				// Update packet information
				uint8_t packetType	   = buffer[1];
				uint8_t packetChecksum = buffer[idx - 1];

				// Compute checksum
				uint8_t computed = packetType ^ buffer[2];
				for ( uint8_t i = 0; i < expectedLength; ++i ) {
					computed ^= buffer[3 + i];
				}

				// Respond to valid checksum
				if ( computed == packetChecksum ) {

					// Select packet type
					if ( packetType == 'D' ) {	  // Packet in, drive

						// Update system state
						shared->System.state = "RUNNING";

						// Parse packet
						Packet_DrivePWM* packet = ( Packet_DrivePWM* )&buffer[3];
						ParseIncomingDrivePacket( packet );

					} else if ( packetType == 'L' ) {

						// Update system state
						shared->System.state = "MEASURE_LIMITS";

						// Parse packet
						Packet_MeasureLimits* packet = ( Packet_MeasureLimits* )&buffer[3];
						ParseIncomingLimitsPacket( packet );
					}
				} else {
					// Checksum failed
				}

				// Reset parser
				state = 0;
				idx	  = 0;
			}
		}

		// Reset on overflow if index greater than buffer size
		if ( idx >= sizeof( buffer ) ) {
			state = 0;
			idx	  = 0;
		}
	}
}


/** PARSING FUNCTIONS **/

/**
	 * @brief Parse incoming drive packet
	 * 
	 * @param pkt Incoming packet
	 */
void T_SerialClass::ParseIncomingDrivePacket( Packet_DrivePWM* pkt ) {
	//
	shared->Amplifier.isEnabled		= pkt->isEnabled;
	shared->Amplifier.commandedPwmA = pkt->pwmA;
	shared->Amplifier.commandedPwmB = pkt->pwmB;
	shared->Amplifier.commandedPwmC = pkt->pwmC;

	// Echo packet back
	SendDrivePacketEcho( pkt );
}



/**
	 * @brief Parse incoming limits packet
	 * 
	 * @param pkt Incoming packet
	 */
void T_SerialClass::ParseIncomingLimitsPacket( Packet_MeasureLimits* pkt ) {
	//
	shared->Amplifier.isEnabled = pkt->isEnabled;

	// Echo packet back
	SendEncoderPacketEcho( pkt );
}



void T_SerialClass::SendDrivePacketEcho( Packet_DrivePWM* pkt ) {

	// Copy packet
	Packet_DrivePWM packet = *pkt;

	// Build full packet
	const uint8_t startByte		= 0xAA;
	const uint8_t packetType	= 'D';
	const uint8_t payloadLength = sizeof( packet );

	// Compute checksum
	uint8_t	 checkSum = packetType ^ payloadLength;
	uint8_t* raw	  = reinterpret_cast<uint8_t*>( &packet );
	for ( uint8_t i = 0; i < payloadLength; ++i ) {
		checkSum ^= raw[i];
	}

	// Build packet buffer
	uint8_t buffer[64];
	size_t	idx	  = 0;
	buffer[idx++] = startByte;
	buffer[idx++] = packetType;
	buffer[idx++] = payloadLength;

	// Copy buffer into packet
	memcpy( &buffer[idx], &packet, payloadLength );
	idx += payloadLength;
	buffer[idx++] = checkSum;

	// Send over serial port 0
	size_t bytesWritten = SerialOut.write( buffer, idx );
	if ( bytesWritten == 0 ) {
		// Failed
	}
}



void T_SerialClass::SendEncoderPacketEcho( Packet_MeasureLimits* pkt ) {

	// Copy packet
	Packet_MeasureLimits packet;

	// Add packet data
	packet.isEnabled = shared->Amplifier.isEnabled;
	packet.encA		 = shared->Amplifier.encoderCountA;
	packet.encB		 = shared->Amplifier.encoderCountB;
	packet.encC		 = shared->Amplifier.encoderCountC;

	// Build full packet
	const uint8_t startByte		= 0xAA;
	const uint8_t packetType	= 'L';
	const uint8_t payloadLength = sizeof( packet );

	// Compute checksum
	uint8_t	 checkSum = packetType ^ payloadLength;
	uint8_t* raw	  = reinterpret_cast<uint8_t*>( &packet );
	for ( uint8_t i = 0; i < payloadLength; ++i ) {
		checkSum ^= raw[i];
	}

	// Build packet buffer
	uint8_t buffer[64];
	size_t	idx	  = 0;
	buffer[idx++] = startByte;
	buffer[idx++] = packetType;
	buffer[idx++] = payloadLength;

	// Copy buffer into packet
	memcpy( &buffer[idx], &packet, payloadLength );
	idx += payloadLength;
	buffer[idx++] = checkSum;

	// Send over serial port 0
	size_t bytesWritten = SerialOut.write( buffer, idx );
	if ( bytesWritten == 0 ) {
		// Failed
	}
}
