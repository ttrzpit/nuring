/** NURingTeensyFirmware **/

#include <Arduino.h>

// System data manager object handle
#include "T_SharedDataManagerClass.h"	 // Shared data manager header
SharedDataManager DataHandle;


// Custom libraries
#include "T_AmplifierClass.h"	 // Amplifier header
#include "T_Config.h"			 // Global config constants
#include "T_LEDClass.h"			 // LED header
#include "T_SerialClass.h"		 // Serial header


// Custom classes
T_AmplifierClass Amplifier( DataHandle );
T_LEDClass		 LEDs( DataHandle );
T_SerialClass	 SerialPort( DataHandle );


// Handle to shared data
auto shared = DataHandle.getData();


// Interval Timer
IntervalTimer IT_Amplifiers;


/** FUNCTION PROTOTYPES **/
void IT_AmplifierCallback();
void SwitchState();


/**
 * @brief Main program setup
 * 
 */
void setup() {

	// Initialize serial ports
	SerialPort.Begin();

	// Initialize LEDs
	LEDs.Begin();

	// Initialize amplifiers
	Amplifier.Begin();

	// Update
	shared->LED.isOnA = true;

	// Start interval timers
	IT_Amplifiers.begin( IT_AmplifierCallback, shared->Timing.periodAmplifier );
}



/**
 * @brief Main program loop
 * 
 * 
 */
void loop() {

	// Update serial port
	SerialPort.Update();

	// Update LEDs
	LEDs.Update();

	// Check system state
	SwitchState();
}



void IT_AmplifierCallback() {

	// Update amplifier
	Amplifier.Update();
}

/**
 * @brief Change state 
 * 
 */
void SwitchState() {

	// Select state
	if ( shared->System.state == "RUNNING" ) {

		// Update status LED
		shared->LED.isOnB = true;

	} else if ( shared->System.state == "MEASURE_LIMITS" ) {

		// Update status LED
		shared->LED.isOnB = true;

		

	} else {

		// Update status LED
		shared->LED.isOnB = false;
	}
}