#pragma once

// System data manager
#include "SystemDataManager.h"

// OpenCV core functions
#include <opencv2/calib3d.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>


class CaptureClass {

public:
	// Data manager handle
	CaptureClass( SystemDataManager& dataHandle );

	// Public functions
	void GetFrame();

	// Public variables
	bool FLAG_frameReady = false;

private:
	// Data manager handle
	SystemDataManager& dataHandle;

	// Capture variables
	cv::VideoCapture Capture;

	// Private functions
	void Initialize();
};