#pragma once

#include <iostream>

#include <memory>
#include <mutex>
#include <opencv2/core.hpp>
#include <shared_mutex>

#include "config.h"

// Container for marker information
struct Marker {
	short		ID					 = 0;
	bool		present				 = false;
	cv::Point3i error3D				 = cv::Point3i( 0, 0, 0 );
	cv::Point2i error2D				 = cv::Point2i( 0, 0 );
	float		theta				 = 0.0f;
	short		errorMagnitude3D	 = 0;
	short		errorMagnitude2D	 = 0;
	short		errorMagnitudeNorm2D = 0;
	float		errorTheta			 = 0.0f;
};

// Shared system variable container
struct ManagedData {

	// System flags
	bool FLAG_RUNNING = true;

	// OpenCV image matrices
	cv::Mat matFrameRaw	 = cv::Mat( CONFIG_CAM_HEIGHT, CONFIG_CAM_WIDTH, CV_8UC3 );
	cv::Mat matFrameGray = cv::Mat( CONFIG_CAM_HEIGHT, CONFIG_CAM_WIDTH, CV_8UC3 );
	cv::Mat matRemap1;
	cv::Mat matRemap2;

	// Mutex controller
	std::shared_mutex sharedMutex;
};

class SystemDataManager {
public:
	SystemDataManager()
		: data( std::make_shared<ManagedData>() ) { }
	std::shared_ptr<ManagedData> getData() {
		return data;
	}

private:
	std::shared_ptr<ManagedData> data;
};