#include "CaptureClass.h"

// Constructor
CaptureClass::CaptureClass( SystemDataManager& ctx )
	: dataHandle( ctx ) {
	Initialize();
}

// void CaptureClass::GetFrame() {

// 	// Pull data pointer
// 	auto sharedData = dataHandle.getData() ;

// 	// Clear frame ready flag
// 	FLAG_frameReady = false ;
// }

void CaptureClass::Initialize() {

	// Pull access to data
	auto								sharedData = dataHandle.getData();
	std::unique_lock<std::shared_mutex> lock( sharedData->sharedMutex );

	// Configure OpenCV Optimizations
	cv::setUseOptimized( true );

	// Initialize undistort map tool
	cv::initUndistortRectifyMap( CONFIG_CAMERA_MATRIX, CONFIG_DISTORTION_COEFFS, cv::Mat(), CONFIG_CAMERA_MATRIX, sharedData->matFrameRaw.size(), CV_32F, sharedData->matRemap1, sharedData->matRemap2 );

	// Try catch to open camera device
	try {
		// Capture device
		Capture.open( "/dev/video0", cv::CAP_V4L2 );

		// Capture settings
		Capture.set( cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc( 'M', 'J', 'P', 'G' ) );
		Capture.set( cv::CAP_PROP_FRAME_WIDTH, CONFIG_CAM_WIDTH );
		Capture.set( cv::CAP_PROP_FRAME_HEIGHT, CONFIG_CAM_HEIGHT );
		Capture.set( cv::CAP_PROP_FPS, CONFIG_CAM_FRAMERATE );
		Capture.set( cv::CAP_PROP_HW_ACCELERATION, cv::VIDEO_ACCELERATION_ANY );

		// Camera settings
		Capture.set( cv::CAP_PROP_BRIGHTNESS, CONFIG_CAM_BRIGHTNESS );
		Capture.set( cv::CAP_PROP_CONTRAST, CONFIG_CAM_CONTRAST );
		Capture.set( cv::CAP_PROP_SATURATION, CONFIG_CAM_SATURATION );
		Capture.set( cv::CAP_PROP_HUE, CONFIG_CAM_HUE );
		Capture.set( cv::CAP_PROP_AUTO_WB, CONFIG_CAM_AUTO_WHITEBALANCE );
		Capture.set( cv::CAP_PROP_GAMMA, CONFIG_CAM_GAMMA );
		Capture.set( cv::CAP_PROP_GAIN, CONFIG_CAM_GAIN );
		Capture.set( cv::CAP_PROP_SHARPNESS, CONFIG_CAM_SHARPNESS );
		Capture.set( cv::CAP_PROP_BACKLIGHT, CONFIG_CAM_BACKLIGHT );
		Capture.set( cv::CAP_PROP_AUTO_EXPOSURE, CONFIG_CAM_AUTO_EXPOSURE );
		Capture.set( cv::CAP_PROP_EXPOSURE, CONFIG_CAM_EXPOSURE_LEVEL );
		Capture.set( cv::CAP_PROP_PAN, CONFIG_CAM_PAN );
		Capture.set( cv::CAP_PROP_TILT, CONFIG_CAM_TILT );
		Capture.set( cv::CAP_PROP_FOCUS, CONFIG_CAM_FOCUS_LEVEL );
		Capture.set( cv::CAP_PROP_AUTOFOCUS, CONFIG_CAM_AUTO_FOCUS );
		Capture.set( cv::CAP_PROP_ZOOM, CONFIG_CAM_ZOOM );

		// Ensure capture devices open and running
		if( !Capture.isOpened() ) {
			std::cerr << "Error: Could not open the camera." << std::endl;
		}
	} catch( cv::Exception& e ) {
		std::cout << "Exception in CameraInterface::Begin(): " << e.msg << "\n";
	}

	// Output confirmation
	std::cout << "CaptureClass: Camera initialized at ( " << Capture.get( cv::CAP_PROP_FRAME_HEIGHT ) << " x " << Capture.get( cv::CAP_PROP_FRAME_WIDTH ) << " ) @ " << Capture.get( cv::CAP_PROP_FPS ) << " fps, mode = " << Capture.get( cv::CAP_PROP_BACKEND )
			  << " , Accel = " << Capture.get( cv::CAP_PROP_HW_ACCELERATION ) << "\n";
}