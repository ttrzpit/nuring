#pragma once

// OpenCV core functions
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

// Memory for shared data
#include <memory>

// Configuration
#include <config.h>

// For std::clamp
#include <cmath>

// Forward declarations
class SystemDataManager;
struct ManagedData;



/** 
 * @brief Display class definition
 */
class DisplayClass {

public:
	// Data manager handle
	DisplayClass( SystemDataManager& dataHandle );

	// Public functions
	void Update();
	void ShowShortcuts();
	void ShowVisualizer();
	void UpdateVisualizer();
	void ClearVisualizer();
	void ShowAngle();
	void UpdateAngle();
	void CheckOptions();


	// Public variables
	std::vector<cv::Point3i> trailPoints;
	std::vector<int>		 trailColor;
	int						 trailCounter  = 0;
	int						 trailInterval = 1;
	int						 trailLimit	   = 1000;

private:
	// Data manager handle
	SystemDataManager&			 dataHandle;
	std::shared_ptr<ManagedData> shared;

	// Private functions
	void		ShowInterface();
	void		AddText();
	void		DrawCell( std::string str, std::string cell0, short width, short height, float sz, cv::Scalar textColor, cv::Scalar fillColor, bool centered );
	void		DrawCellBorder( std::string cell0, short width, short height, uint8_t thickness, cv::Scalar color );
	void		DrawKeyCell( std::string str, std::string cell0, short width, short height, float sz, cv::Scalar textColor, cv::Scalar fillColor, bool centered );
	cv::Point2i ProjectIsometric( const cv::Point3i& p3d );
	cv::Point2i GetForwardDirectionFromPose( const cv::Vec3d rvec, const cv::Vec3d tvec, const cv::Mat& cameraMatrix, const cv::Mat& distCoeffs, float axisLength );
	static void onMouse( int event, int x, int y, int flags, void* userData );

	// Window names
	std::string winAngle	  = "Angle Visualizer";
	std::string winInterface  = "NURing Interface";
	std::string winShortcuts  = "Keyboard Shortcuts";
	std::string winVisualizer = "3D Visualizer";

	// Private variables
	float	 fontTitle	= 0.0f;
	float	 fontHeader = 0.0f;
	float	 fontBody	= 0.0f;
	cv::Size textSize;
	// short	 cellPx = 40;
	short WIDTH	 = CONFIG_DIS_CELL_WIDTH;
	short HEIGHT = CONFIG_DIS_CELL_HEIGHT;
	short c0	 = 0;
	short r0	 = 0;
	short nR	 = 0;
	short nC	 = 0;
	short cW	 = 0;
	short rH	 = 0;
	short textX	 = 0;
	short textY	 = 0;

	// Keyboard shortcut variables
	float	 key_fontHeader = 0.0f;
	float	 key_fontBody	= 0.0f;
	cv::Size key_textSize;
	short	 key_WIDTH	= CONFIG_DIS_KEY_CELL_WIDTH;
	short	 key_HEIGHT = CONFIG_DIS_KEY_CELL_HEIGHT;
	short	 key_c0		= 0;
	short	 key_r0		= 0;
	short	 key_nR		= 0;
	short	 key_nC		= 0;
	short	 key_cW		= 0;
	short	 key_rH		= 0;
	short	 key_textX	= 0;
	short	 key_textY	= 0;

	// Visualizer settings
	std::vector<cv::Point2i> ProjectedCorners;
	cv::Mat					 matShortcuts  = cv::Mat( CONFIG_DIS_HEIGHT, CONFIG_DIS_KEY_WIDTH, CV_8UC3 );
	cv::Mat					 matVisualizer = cv::Mat( CONFIG_DIS_VIZ_HEIGHT, CONFIG_DIS_VIZ_WIDTH, CV_8UC3 );
	cv::Mat					 matAngles	   = cv::Mat( CONFIG_DIS_ANGLE_HEIGHT, CONFIG_DIS_ANGLE_WIDTH, CV_8UC3 );
	int						 vizLimXY	   = 500;
	int						 vizLimZ	   = 1000;
	const float				 focalLength   = 2400.0f;		//800
	float					 azimuth	   = CV_PI / 4;		// 45 degrees 4
	float					 elevation	   = CV_PI / 16;	// 30 degrees 6

	// Define 3D corners of a cube
	const std::vector<cv::Point3i> cubeCorners = { { -vizLimXY, -vizLimXY, 0 }, { vizLimXY, -vizLimXY, 0 }, { vizLimXY, vizLimXY, 0 }, { -vizLimXY, vizLimXY, 0 }, { -vizLimXY, -vizLimXY, vizLimZ }, { vizLimXY, -vizLimXY, vizLimZ }, { vizLimXY, vizLimXY, vizLimZ }, { -vizLimXY, vizLimXY, vizLimZ } };

	// Variables for motor viz
	float limA = 0.0f;
	float limB = 0.0f;
	float limC = 0.0f;

	// Edges of 3D cube
	const std::vector<std::pair<int, int>> edges = {
		{ 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 0 },	   // bottom face
		{ 4, 5 }, { 5, 6 }, { 6, 7 }, { 7, 4 },	   // top face
		{ 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 }	   // vertical edges
	};
};
