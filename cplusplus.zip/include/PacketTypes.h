#pragma once

#pragma pack( push, 1 )	   // Avoid padding

struct Packet_DrivePWM {
	uint8_t	 counter;
	uint8_t	 isEnabled;
	uint16_t pwmA;
	uint16_t pwmB;
	uint16_t pwmC;
};

// Packet for encoder values
struct Packet_MeasureLimits {

	// Encoder values
    uint8_t isEnabled ; 
	int16_t encA;	  // Encoder for A
	int16_t encB;	  // Encoder for B
	int16_t encC;	  // Encoder for C
};

#pragma pack( pop )
